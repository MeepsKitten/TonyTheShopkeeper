<template>
  <div>
    <h1>Welcome to the Home Page</h1>
<p>This is some placeholder text for the home page.</p>
<nav>
<nuxt-link to="/">Home</nuxt-link>
<nuxt-link to="/perks">Perks</nuxt-link>

</nav>

  </div>
</template>